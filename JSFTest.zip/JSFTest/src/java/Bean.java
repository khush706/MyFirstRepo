
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author HACKER
 */
@RequestScoped
@SessionScoped
@ManagedBean(name = "Bean")
@Named("Bean")
public class Bean {

    Connection con;
    Statement stmt;
    
    public String email ,password;

    private String Email;
    private String Password;

    public String Values() {
        if (getEmail().equals("khush")) {
            return "khush";
        } else {
            return "error";
        }
    }

    public Bean() {
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    

    public void submit() {
        check();
        
    }

    public String check() {
        String ans = "";
        try{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/JSF", "khush", "khush");
        String query = "select * from Detail";
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        
        while (rs.next()) {
        email = rs.getString("email");
        password = rs.getString("password");
             if(email.equals(this.getEmail()) && password.equals(this.getPassword())){
                ans = "khush";    
                 
            }else{
                ans = "error";
            }
            
            
           
        }
        }catch(SQLException th){
            
        }
        System.out.print(ans);
        return ans;
        
     
       
    }
    
    public String Register(){
        return "register";
    }
}
