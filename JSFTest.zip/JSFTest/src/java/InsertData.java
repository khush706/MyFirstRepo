
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author HACKER
 */

@RequestScoped
@SessionScoped
@ManagedBean(name = "InsertBean")
@Named("InsertBean")
public class InsertData {

    private String Email,Password;

    public InsertData() {
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    
    Connection con;
    Statement stmt;

   public String Insert() {
        int result = 0;
        
        String ret = "";

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/JSF", "khush", "khush");
                    
            
            String query = "insert into Detail(email,password) values(?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, this.getEmail());
            ps.setString(2, this.getPassword());
            ps.executeUpdate();
            ret = "Inserted";

        } catch (ClassNotFoundException | SQLException th) {
             ret = "NotInserted";
        }
       
        return ret;

    }

    

}
